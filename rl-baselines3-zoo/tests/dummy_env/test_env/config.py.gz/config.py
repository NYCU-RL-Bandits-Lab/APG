hyperparams = {
    "TestEnv-v0": {
        "policy": "MlpPolicy",
        "n_timesteps": 20000,
    }
}
